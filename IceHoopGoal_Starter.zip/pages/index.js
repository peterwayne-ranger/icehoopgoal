export default function Home() {
  return <div>Welcome to IceHoopGoal</div>;
}